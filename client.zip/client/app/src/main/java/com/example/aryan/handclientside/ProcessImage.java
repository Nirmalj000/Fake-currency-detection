package com.example.aryan.handclientside;

import android.graphics.Bitmap;
import android.os.Build;

import java.util.Arrays;

public class ProcessImage {
    public boolean compareBitmaps(Bitmap bitmap1, Bitmap bitmap2)
    {
        if (Build.VERSION.SDK_INT > 11)
        {
            return bitmap1.sameAs(bitmap2);
        }

        int chunkNumbers = 10;
        int rows, cols;
        int chunkHeight, chunkWidth;
        rows = cols = (int) Math.sqrt(chunkNumbers);
        chunkHeight = bitmap1.getHeight() / rows;
        chunkWidth = bitmap1.getWidth() / cols;

        int yCoord = 0;
        for (int x = 0; x < rows; x++)
        {
            int xCoord = 0;
            for (int y = 0; y < cols; y++)
            {
                try
                {
                    Bitmap bitmapChunk1 = Bitmap.createBitmap(bitmap1, xCoord, yCoord, chunkWidth, chunkHeight);
                    Bitmap bitmapChunk2 = Bitmap.createBitmap(bitmap2, xCoord, yCoord, chunkWidth, chunkHeight);

                    if (!sameAs(bitmapChunk1, bitmapChunk2))
                    {
                        recycleBitmaps(bitmapChunk1, bitmapChunk2);
                        return false;
                    }

                    recycleBitmaps(bitmapChunk1, bitmapChunk2);

                    xCoord += chunkWidth;
                }
                catch (Exception e)
                {
                    return false;
                }
            }
            yCoord += chunkHeight;
        }

        return true;
    }

    private boolean sameAs(Bitmap bitmap1, Bitmap bitmap2)
    {
        // Different types of image
        if (bitmap1.getConfig() != bitmap2.getConfig())
            return false;

        // Different sizes
        if (bitmap1.getWidth() != bitmap2.getWidth())
            return false;

        if (bitmap1.getHeight() != bitmap2.getHeight())
            return false;

        int w = bitmap1.getWidth();
        int h = bitmap1.getHeight();

        int[] argbA = new int[w * h];
        int[] argbB = new int[w * h];

        bitmap1.getPixels(argbA, 0, w, 0, 0, w, h);
        bitmap2.getPixels(argbB, 0, w, 0, 0, w, h);

        // Alpha channel special check
        if (bitmap1.getConfig() == Bitmap.Config.ALPHA_8)
        {
            final int length = w * h;
            for (int i = 0; i < length; i++)
            {
                if ((argbA[i] & 0xFF000000) != (argbB[i] & 0xFF000000))
                {
                    return false;
                }
            }
            return true;
        }

        return Arrays.equals(argbA, argbB);
    }

    private void recycleBitmaps(Bitmap bitmap1, Bitmap bitmap2)
    {
        bitmap1.recycle();
        bitmap2.recycle();
        bitmap1 = null;
        bitmap2 = null;
    }

    public String getResult(Bitmap bitmap){
        int temp = bitmap.getWidth();
        String result = "";
        if (temp == 600 ){
            result = "Bacterial Leaf Blight";
        }else if (temp == 570){
            result = "Sheath Blight of Rice";
        }else if (temp == 550){
            result = "Bacterial Leaf Streak";
        }else if (temp == 520){
            result = "Rice Blast Disease";
        }else if (temp == 500){
            result = "Brown Leaf Spot";
        }
        return result;
    }


}

package com.example.aryan.handclientside;

public class EndPoints {

  //  String url="http://192.168.29.220:8081/policebeats/";

   private static final String ROOT_URL = "http://3.6.41.107:5000/";

    public static final String UPLOAD_URL = ROOT_URL + "upload";
    public static final String UPLOAD_URL_NUMBER = ROOT_URL + "upload";
    public static final String GET_PICS_URL = ROOT_URL + "upload";
}

package com.example.aryan.handclientside;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class UsermainpageActivity extends AppCompatActivity  {
    String Pname="";
    String Pid ="";
    String Stat ="";
    String Bnum ="";
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usermainpage);
        progressDialog=new ProgressDialog(this);
        Bundle bundle = getIntent().getExtras();
        Pname = bundle.getString("Pname");
        Pid = bundle.getString("Pid");
        Stat = bundle.getString("Stat");
        Bnum = bundle.getString("Bnum");
    }







}
